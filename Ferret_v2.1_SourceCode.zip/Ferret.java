

import javax.swing.JFrame;
class Ferret {
	public static void main (String[] args){
		GUI ferretGUI = new GUI();
		ferretGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
